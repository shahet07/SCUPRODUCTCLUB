import { Button } from '@/components/ui/button';
import { ArrowRight, Users, Target, Lightbulb } from 'lucide-react';
import { Link } from 'react-router-dom';

const HeroSection = () => {
  return (
    <section className="relative bg-gradient-hero text-primary-foreground overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-grid-white/10 bg-grid-16" />
      
      <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-montserrat font-bold mb-6 leading-tight">
            🚀 Shaping the Next Generation of
            <span className="block font-allerta bg-gradient-to-r from-white to-scu-gold bg-clip-text text-transparent">
              Product Leaders at SCU
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl mb-8 font-poppins text-white/90 max-w-3xl mx-auto">
            We are Santa Clara University's hub for students passionate about product management, technology, and innovation. Whether you're exploring PM for the first time or preparing for your dream role, you'll find community, learning, and opportunities here.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Button asChild
              size="lg" 
              className="bg-white text-primary hover:bg-blue-50 shadow-glow text-lg px-8 py-6"
            >
              <Link to="/join">
                Join the Club
                <ArrowRight className="ml-2" size={20} />
              </Link>
            </Button>
            <Button asChild
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white/10 text-lg px-8 py-6"
            >
              <Link to="/events">See Upcoming Events</Link>
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            <div className="text-center">
              <div className="flex items-center justify-center w-16 h-16 bg-white/10 rounded-full mx-auto mb-4">
                <Users className="w-8 h-8" />
              </div>
              <div className="text-3xl font-bold mb-2">200+</div>
              <div className="text-blue-100">Active Members</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center w-16 h-16 bg-white/10 rounded-full mx-auto mb-4">
                <Target className="w-8 h-8" />
              </div>
              <div className="text-3xl font-bold mb-2">50+</div>
              <div className="text-blue-100">Industry Events</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center w-16 h-16 bg-white/10 rounded-full mx-auto mb-4">
                <Lightbulb className="w-8 h-8" />
              </div>
              <div className="text-3xl font-bold mb-2">100+</div>
              <div className="text-blue-100">Career Placements</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;