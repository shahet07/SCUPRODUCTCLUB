import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Layout from "@/components/Layout";

const teamMembers = [
  {
    name: "Suyog Ingle",
    role: "President",
    initials: "SI"
  },
  {
    name: "Priyal Jain", 
    role: "Product Marketing",
    initials: "PJ"
  },
  {
    name: "Prisni Rath",
    role: "External Affairs", 
    initials: "PR"
  },
  {
    name: "Het Bhavesh Shah",
    role: "Technology and Tool",
    initials: "HS"
  },
  {
    name: "Linh Tran",
    role: "Strategy",
    initials: "LT"
  },
  {
    name: "Nithyasree Balasubramanian",
    role: "Operations & HR",
    initials: "NB"
  }
];

const Team = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-16">
        {/* Header Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Meet Our Leadership Team
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Our passionate leaders are dedicated to building an inclusive community 
            of product enthusiasts and future product managers at Santa Clara University.
          </p>
        </div>

        {/* Team Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {teamMembers.map((member, index) => (
            <Card key={index} className="bg-card hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-8 text-center">
                <Avatar className="w-24 h-24 mx-auto mb-6">
                  <AvatarFallback className="text-lg font-semibold bg-primary text-primary-foreground">
                    {member.initials}
                  </AvatarFallback>
                </Avatar>
                <h3 className="text-xl font-bold text-foreground mb-2">
                  {member.name}
                </h3>
                <p className="text-primary font-medium">
                  {member.role}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <Card className="bg-primary/5 border-primary/20 max-w-2xl mx-auto">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">
                Want to Get Involved?
              </h2>
              <p className="text-muted-foreground mb-6">
                Join our community and connect with like-minded product enthusiasts. 
                We're always looking for passionate individuals to contribute to our mission.
              </p>
              <a 
                href="https://forms.gle/55CgGmF8h7W2DDEe6" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center rounded-md bg-primary px-6 py-3 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors"
              >
                Join Our Club
              </a>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Team;