import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Download, ExternalLink, BookOpen, Video, FileText, Users } from 'lucide-react';

const Resources = () => {
  const productBasics = [
    {
      title: "Product Management 101",
      description: "Comprehensive guide covering the fundamentals of product management",
      type: "PDF Guide",
      link: "#"
    },
    {
      title: "User Research Methods",
      description: "Essential techniques for understanding your users and their needs",
      type: "Interactive Guide",
      link: "#"
    },
    {
      title: "Product Strategy Framework",
      description: "Step-by-step framework for developing winning product strategies",
      type: "Template",
      link: "#"
    }
  ];

  const careerResources = [
    {
      title: "PM Resume Template",
      description: "Professional resume template specifically designed for product management roles",
      type: "Template",
      downloads: 340,
      link: "#"
    },
    {
      title: "Interview Prep Guide",
      description: "Complete guide with common PM interview questions and frameworks",
      type: "PDF Guide",
      downloads: 520,
      link: "#"
    },
    {
      title: "Salary Negotiation Tips",
      description: "Strategic advice for negotiating your product management salary",
      type: "Article",
      downloads: 280,
      link: "#"
    },
    {
      title: "PM Career Roadmap",
      description: "Visual roadmap showing different PM career paths and progression",
      type: "Infographic",
      downloads: 410,
      link: "#"
    }
  ];

  const eventRecordings = [
    {
      title: "Product Strategy Workshop",
      speaker: "Sarah Chen, Google",
      date: "February 20, 2024",
      duration: "90 min",
      views: 245,
      link: "#"
    },
    {
      title: "User Research Masterclass",
      speaker: "Dr. Emily Rodriguez",
      date: "January 25, 2024",
      duration: "75 min",
      views: 180,
      link: "#"
    },
    {
      title: "Product Analytics Deep Dive",
      speaker: "Mark Johnson, Meta",
      date: "January 10, 2024",
      duration: "60 min",
      views: 320,
      link: "#"
    }
  ];

  return (
    <Layout>
      <div className="bg-gradient-subtle">
        {/* Header */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Resources</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Access our curated collection of guides, templates, and recordings to accelerate your product management journey.
            </p>
          </div>
        </section>

        {/* Product Management Basics */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-3xl font-bold mb-8 flex items-center">
            <BookOpen className="w-8 h-8 mr-3 text-primary" />
            Product Management Basics
          </h2>
          <p className="text-muted-foreground mb-8 max-w-3xl">
            Essential resources for understanding the fundamentals of product management, from strategy to execution.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {productBasics.map((resource, index) => (
              <Card key={index} className="shadow-elegant hover:shadow-glow transition-all duration-300">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <Badge className="bg-gradient-primary text-primary-foreground">
                      {resource.type}
                    </Badge>
                  </div>
                  <CardTitle className="text-lg">{resource.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4 text-sm">
                    {resource.description}
                  </p>
                  <Button className="w-full bg-gradient-primary shadow-elegant">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Access Resource
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Career Resources */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-3xl font-bold mb-8 flex items-center">
            <Users className="w-8 h-8 mr-3 text-primary" />
            Career Resources
          </h2>
          <p className="text-muted-foreground mb-8 max-w-3xl">
            Downloadable guides, templates, and tips to help you land your dream product management role.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {careerResources.map((resource, index) => (
              <Card key={index} className="shadow-elegant hover:shadow-glow transition-all duration-300">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <Badge variant="outline">{resource.type}</Badge>
                    <span className="text-sm text-muted-foreground">{resource.downloads} downloads</span>
                  </div>
                  <CardTitle className="text-lg">{resource.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4 text-sm">
                    {resource.description}
                  </p>
                  <Button className="w-full bg-gradient-primary shadow-elegant">
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Event Recordings */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-3xl font-bold mb-8 flex items-center">
            <Video className="w-8 h-8 mr-3 text-primary" />
            Event Recordings & Slides
          </h2>
          <p className="text-muted-foreground mb-8 max-w-3xl">
            Catch up on past events with our recorded sessions and downloadable presentation materials.
          </p>
          
          <div className="space-y-6">
            {eventRecordings.map((recording, index) => (
              <Card key={index} className="shadow-elegant">
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold mb-2">{recording.title}</h3>
                      <div className="flex flex-wrap gap-4 text-muted-foreground text-sm mb-4 lg:mb-0">
                        <span className="flex items-center">
                          <Users className="w-4 h-4 mr-1" />
                          {recording.speaker}
                        </span>
                        <span>{recording.date}</span>
                        <span>{recording.duration}</span>
                        <span>{recording.views} views</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <FileText className="w-4 h-4 mr-2" />
                        Slides
                      </Button>
                      <Button className="bg-gradient-primary" size="sm">
                        <Video className="w-4 h-4 mr-2" />
                        Watch
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default Resources;