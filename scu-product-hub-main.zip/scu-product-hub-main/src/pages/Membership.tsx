import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, Star, Users, Calendar, BookOpen, Network } from 'lucide-react';

const Membership = () => {
  const benefits = [
    {
      icon: <Network className="w-6 h-6" />,
      title: "Exclusive Networking",
      description: "Connect with industry professionals, alumni, and passionate peers in intimate settings."
    },
    {
      icon: <BookOpen className="w-6 h-6" />,
      title: "Skill-Building Workshops",
      description: "Hands-on workshops covering product strategy, user research, analytics, and more."
    },
    {
      icon: <Calendar className="w-6 h-6" />,
      title: "Priority Event Access",
      description: "Get first access to speaker events, company visits, and exclusive sessions."
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Mentorship Program",
      description: "Paired mentorship with industry professionals and senior students."
    }
  ];

  const testimonials = [
    {
      name: "Alex Rodriguez",
      role: "Product Manager at Spotify",
      year: "Class of 2023",
      quote: "The Product Club gave me the foundation and network I needed to land my dream PM role. The workshops and mentorship were invaluable.",
      rating: 5
    },
    {
      name: "Priya Patel",
      role: "APM at Google",
      year: "Class of 2022",
      quote: "Through the club, I discovered my passion for product management and got hands-on experience that set me apart in interviews.",
      rating: 5
    },
    {
      name: "Michael Chen",
      role: "Senior PM at Adobe",
      year: "Class of 2021",
      quote: "The relationships I built in the Product Club continue to be valuable throughout my career. It's more than a club - it's a community.",
      rating: 5
    }
  ];

  const membershipTiers = [
    {
      name: "General Member",
      price: "Free",
      description: "Perfect for getting started with product management",
      features: [
        "Access to general meetings",
        "Basic workshop attendance",
        "Newsletter updates",
        "Resource library access"
      ],
      popular: false
    },
    {
      name: "Premium Member",
      price: "$25/semester",
      description: "For serious PM aspirants ready to dive deep",
      features: [
        "All General Member benefits",
        "Priority event registration",
        "1:1 mentorship matching",
        "Exclusive company visits",
        "Resume review sessions",
        "Mock interview practice"
      ],
      popular: true
    }
  ];

  return (
    <Layout>
      <div className="bg-gradient-subtle">
        {/* Header */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Join Our Community</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Become part of SCU's most active product management community and accelerate your career journey.
            </p>
          </div>
        </section>

        {/* Why Join Section */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-3xl font-bold text-center mb-12">Why Join?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="shadow-elegant text-center">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4 text-primary-foreground">
                    {benefit.icon}
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{benefit.title}</h3>
                  <p className="text-muted-foreground text-sm">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Membership Tiers */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-3xl font-bold text-center mb-12">Membership Options</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {membershipTiers.map((tier, index) => (
              <Card key={index} className={`shadow-elegant ${tier.popular ? 'ring-2 ring-primary shadow-glow' : ''}`}>
                <CardHeader className="text-center">
                  {tier.popular && (
                    <Badge className="bg-gradient-primary text-primary-foreground w-fit mx-auto mb-2">
                      Most Popular
                    </Badge>
                  )}
                  <CardTitle className="text-2xl">{tier.name}</CardTitle>
                  <div className="text-3xl font-bold text-primary">{tier.price}</div>
                  <p className="text-muted-foreground">{tier.description}</p>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {tier.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center">
                        <Check className="w-4 h-4 text-primary mr-2 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className={`w-full ${tier.popular ? 'bg-gradient-primary shadow-elegant' : ''}`}
                    variant={tier.popular ? 'default' : 'outline'}
                  >
                    Join Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Testimonials */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-3xl font-bold text-center mb-12">What Our Members Say</h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="shadow-elegant">
                <CardContent className="p-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, starIndex) => (
                      <Star key={starIndex} className="w-4 h-4 fill-primary text-primary" />
                    ))}
                  </div>
                  <blockquote className="text-muted-foreground mb-4 italic">
                    "{testimonial.quote}"
                  </blockquote>
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.year}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Call to Action */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center bg-gradient-primary rounded-2xl p-8 md:p-12 text-primary-foreground">
            <h2 className="text-3xl font-bold mb-4">Ready to Start Your PM Journey?</h2>
            <p className="text-xl mb-8 opacity-90">
              Join over 200 SCU students who are building their product management careers with us.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-primary hover:bg-blue-50 shadow-elegant">
                Join as Premium Member
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                Start with Free Membership
              </Button>
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default Membership;