import Layout from '@/components/Layout';
import HeroSection from '@/components/HeroSection';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, MapPin, Users, ArrowRight, Star } from 'lucide-react';

const Index = () => {
  const upcomingEvents = [
    {
      title: "Product Strategy Workshop",
      date: "Mar 15",
      time: "6:00 PM",
      location: "Lucas Hall 100",
      speaker: "Sarah Chen, Google"
    },
    {
      title: "Startup Founder Panel",
      date: "Mar 22", 
      time: "7:00 PM",
      location: "Sobrato Tech Center",
      speaker: "Multiple Founders"
    },
    {
      title: "PM Case Competition",
      date: "Apr 5",
      time: "10:00 AM",
      location: "Business School",
      speaker: "Competition Format"
    }
  ];

  return (
    <Layout>
      <HeroSection />
      
      {/* About Preview */}
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-6">About Us Preview</h2>
            <p className="text-muted-foreground text-lg mb-6">
              At SCU Product Club, we connect students with the tools, mentors, and experiences needed to excel in product management. From hands-on workshops to industry panels, we help you build the skills to take ideas from vision to reality.
            </p>
            <Button className="bg-gradient-primary shadow-elegant">
              ➡️ Learn more about our mission
              <ArrowRight className="ml-2" size={16} />
            </Button>
          </div>
          <div className="relative">
            <Card className="shadow-elegant">
              <CardContent className="p-8">
                <div className="grid grid-cols-2 gap-6 text-center">
                  <div>
                    <div className="text-3xl font-bold text-primary mb-2">200+</div>
                    <div className="text-muted-foreground">Active Members</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-primary mb-2">50+</div>
                    <div className="text-muted-foreground">Industry Events</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-primary mb-2">100+</div>
                    <div className="text-muted-foreground">Career Placements</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-primary mb-2">15+</div>
                    <div className="text-muted-foreground">Partner Companies</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Upcoming Events */}
      <section className="bg-gradient-subtle py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Upcoming Events Preview</h2>
            <p className="text-muted-foreground text-lg">
              Build skills. Meet mentors. Get inspired.
            </p>
            <p className="text-muted-foreground">
              From resume workshops to fireside chats with product leaders, our events are designed to prepare you for real-world product roles.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {upcomingEvents.map((event, index) => (
              <Card key={index} className="shadow-elegant hover:shadow-glow transition-all duration-300">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <Badge className="bg-gradient-primary text-primary-foreground">Workshop</Badge>
                    <span className="text-sm text-muted-foreground">{event.date}</span>
                  </div>
                  <CardTitle className="text-lg">{event.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 mb-4 text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-2" />
                      {event.time}
                    </div>
                    <div className="flex items-center">
                      <MapPin className="w-4 h-4 mr-2" />
                      {event.location}
                    </div>
                    <div className="flex items-center">
                      <Users className="w-4 h-4 mr-2" />
                      {event.speaker}
                    </div>
                  </div>
                  <Button className="w-full bg-gradient-primary">Register</Button>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center">
            <Button variant="outline" size="lg">
              ➡️ See all events
              <ArrowRight className="ml-2" size={16} />
            </Button>
          </div>
        </div>
      </section>

      {/* Member Highlight */}
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Member Success Stories</h2>
          <p className="text-muted-foreground text-lg">
            Hear from our members who've landed amazing PM roles
          </p>
        </div>
        
        <Card className="max-w-4xl mx-auto shadow-elegant">
          <CardContent className="p-8 md:p-12">
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="w-24 h-24 bg-gradient-primary rounded-full flex items-center justify-center text-primary-foreground text-2xl font-bold">
                AR
              </div>
              <div className="flex-1 text-center md:text-left">
                <div className="flex justify-center md:justify-start mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                  ))}
                </div>
                <blockquote className="text-lg text-muted-foreground mb-4 italic">
                  "Joining the Product Club gave me the confidence to pursue a PM internship. The workshops and peer community were game-changers."
                </blockquote>
                <div>
                  <div className="font-semibold text-lg">— SCU Student Member</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Partners */}
      <section className="bg-gradient-subtle py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Partners/Sponsors</h2>
            <p className="text-muted-foreground">
              We proudly collaborate with industry leaders, alumni, and faculty to bring the best opportunities to our members.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 items-center opacity-60">
            {['Google', 'Meta', 'Apple', 'Microsoft', 'Adobe', 'Spotify'].map((company, index) => (
              <div key={index} className="text-center">
                <div className="h-12 bg-muted rounded flex items-center justify-center">
                  <span className="font-semibold text-muted-foreground">{company}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
