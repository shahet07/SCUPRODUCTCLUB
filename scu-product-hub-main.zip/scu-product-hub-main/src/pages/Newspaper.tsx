import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, User, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Newspaper = () => {
  const articles = [
    {
      id: 1,
      title: "A New Season, A New Chapter",
      excerpt: "Hello Broncos! As the new leadership team of the SCU Product Club, we're excited to kick off this season with you.",
      author: "SCU Product Club Leadership Team",
      date: "March 20, 2024",
      category: "Leadership",
      readTime: "4 min read"
    },
    {
      id: 2,
      title: "Building Your First Product Roadmap: A Student's Guide",
      excerpt: "Step-by-step guide to creating effective product roadmaps, from vision to execution.",
      author: "Mike Rodriguez",
      date: "March 10, 2024",
      category: "Education",
      readTime: "8 min read"
    },
    {
      id: 3,
      title: "Alumni Spotlight: From SCU to Senior PM at Meta",
      excerpt: "Interview with our alumna about her journey from student to leading product teams at major tech companies.",
      author: "Emily Johnson",
      date: "March 5, 2024",
      category: "Alumni",
      readTime: "6 min read"
    },
    {
      id: 4,
      title: "Event Recap: Product Strategy Workshop with Google PM",
      excerpt: "Key takeaways from our recent workshop covering product strategy, market analysis, and competitive positioning.",
      author: "David Park",
      date: "February 28, 2024",
      category: "Events",
      readTime: "4 min read"
    }
  ];

  const categories = ["All", "Industry Insights", "Education", "Alumni", "Events"];

  return (
    <Layout>
      <div className="bg-gradient-subtle">
        {/* Hero Section */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Product Club Newspaper</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Stay informed with the latest insights, member stories, and industry trends in product management.
            </p>
          </div>
        </section>

        {/* Category Filter */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 pb-8">
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((category) => (
              <Badge
                key={category}
                variant={category === "All" ? "default" : "secondary"}
                className="cursor-pointer hover:bg-primary/80 transition-colors"
              >
                {category}
              </Badge>
            ))}
          </div>
        </section>

        {/* Featured Article */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 pb-16">
          <Card className="shadow-elegant overflow-hidden">
            <CardContent className="p-8">
              <div className="max-w-4xl mx-auto">
                <div className="text-center mb-8">
                  <Badge variant="default" className="mb-4">Featured Article</Badge>
                  <h2 className="text-4xl font-bold mb-4">A New Season, A New Chapter</h2>
                  <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground mb-6">
                    <div className="flex items-center gap-1">
                      <User size={16} />
                      <span>SCU Product Club Leadership Team</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar size={16} />
                      <span>March 20, 2024</span>
                    </div>
                    <span>4 min read</span>
                  </div>
                </div>
                
                <div className="prose prose-lg max-w-none">
                  <p className="text-xl font-medium mb-6">Hello Broncos!</p>
                  
                  <p className="mb-6">
                    As the new leadership team of the SCU Product Club, we're excited to kick off this season with you. 
                    First, a heartfelt thank you and sad adieu to our outgoing leaders. Their energy, passion, and 
                    commitment laid the foundation we now build upon. We have learned so much from them.
                  </p>
                  
                  <p className="mb-6">Now, we look ahead.</p>
                  
                  <p className="mb-8">
                    This year, our mission is clear: to bring together more product enthusiasts, create hands-on 
                    opportunities to learn, and celebrate the journey of becoming future product leaders.
                  </p>
                  
                  <h3 className="text-2xl font-bold mb-4">Get Involved</h3>
                  <ul className="mb-8 space-y-2">
                    <li>Want to sign up for membership? <Button asChild variant="link" className="p-0 h-auto"><a href="https://forms.gle/55CgGmF8h7W2DDEe6" target="_blank" rel="noopener noreferrer">Click here to join</a></Button></li>
                    <li>Got exciting event ideas? Drop them right into the sign-up form — we'd love to hear them!</li>
                    <li>Subscribe to our newsletter on our brand-new website so you don't miss updates.</li>
                    <li>And please, forward this to your friends and fellow Broncos. The more voices we bring in, the stronger our community becomes.</li>
                  </ul>
                  
                  <h3 className="text-2xl font-bold mb-4">Why Join?</h3>
                  <p className="mb-4">Joining the SCU Product Club means:</p>
                  <ul className="mb-8 space-y-2">
                    <li>• Exclusive access to events & workshops</li>
                    <li>• Career resources (we don't gatekeep!)</li>
                    <li>• Networking with alumni & industry pros</li>
                    <li>• A community of like-minded product enthusiasts</li>
                  </ul>
                  
                  <p className="mb-8">Sign up today and be part of the movement.</p>
                  
                  <h3 className="text-2xl font-bold mb-4">Feature a Product Story</h3>
                  <p className="mb-8">
                    Are you a product professional or know someone who is? We would love to spotlight your journey. 
                    Reach out! Your story could inspire the next wave of PMs at SCU.
                  </p>
                  
                  <h3 className="text-2xl font-bold mb-4">Let's Do This Together</h3>
                  <p className="mb-6">
                    We can't wait to learn, grow, and build with you this season. Thanks for being part of the 
                    SCU Product Club. We will see you at our next event!
                  </p>
                  
                  <p className="font-medium">
                    Yours truly,<br />
                    SCU Product Club Leadership Team
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Articles Grid */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 pb-16">
          <h2 className="text-3xl font-bold text-center mb-12">Latest Articles</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {articles.slice(1).map((article) => (
              <Card key={article.id} className="shadow-elegant hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader>
                  <Badge variant="outline" className="w-fit mb-2">{article.category}</Badge>
                  <CardTitle className="text-xl line-clamp-2">{article.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4 line-clamp-3">{article.excerpt}</p>
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <User size={14} />
                      <span>{article.author}</span>
                    </div>
                    <span>{article.readTime}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">{article.date}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Newsletter Signup */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 pb-16">
          <Card className="shadow-elegant">
            <CardContent className="p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">Stay Updated</h3>
              <p className="text-muted-foreground mb-6">
                Subscribe to our newsletter to get the latest articles and insights delivered to your inbox.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <Button className="bg-gradient-primary">Subscribe</Button>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </Layout>
  );
};

export default Newspaper;