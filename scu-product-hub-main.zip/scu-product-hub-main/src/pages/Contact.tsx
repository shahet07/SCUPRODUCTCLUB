import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Mail, MapPin, Instagram, Linkedin, Twitter } from 'lucide-react';

const Contact = () => {
  return (
    <Layout>
      <div className="bg-gradient-subtle">
        {/* Header */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Contact Us</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Have questions about our events, membership, or product management? We'd love to hear from you.
            </p>
          </div>
        </section>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="shadow-elegant">
              <CardHeader>
                <CardTitle className="text-2xl">Send us a Message</CardTitle>
              </CardHeader>
              <CardContent>
                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input id="firstName" placeholder="John" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input id="lastName" placeholder="Doe" />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" placeholder="john.doe@scu.edu" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject</Label>
                    <Input id="subject" placeholder="Question about membership" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="message">Message</Label>
                    <Textarea 
                      id="message" 
                      placeholder="Tell us how we can help you..."
                      className="min-h-[120px]"
                    />
                  </div>
                  
                  <Button className="w-full bg-gradient-primary shadow-elegant">
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <div className="space-y-8">
              {/* Club Information */}
              <Card className="shadow-elegant">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Club Information</h3>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <Mail className="w-5 h-5 text-primary mt-1" />
                      <div>
                        <p className="font-medium">Email</p>
                        <p className="text-muted-foreground">scuproductclub@gmail.com</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <MapPin className="w-5 h-5 text-primary mt-1" />
                      <div>
                        <p className="font-medium">Location</p>
                        <p className="text-muted-foreground">
                          Santa Clara University<br />
                          500 El Camino Real<br />
                          Santa Clara, CA 95053
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Social Media */}
              <Card className="shadow-elegant">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Follow Us</h3>
                  <p className="text-muted-foreground mb-6">
                    Stay connected with us on social media for the latest updates, events, and opportunities.
                  </p>
                  <div className="flex space-x-4">
                    <a 
                      href="#" 
                      className="w-10 h-10 bg-gradient-primary rounded-full flex items-center justify-center text-primary-foreground hover:shadow-glow transition-all duration-300"
                    >
                      <Instagram size={20} />
                    </a>
                    <a 
                      href="#" 
                      className="w-10 h-10 bg-gradient-primary rounded-full flex items-center justify-center text-primary-foreground hover:shadow-glow transition-all duration-300"
                    >
                      <Linkedin size={20} />
                    </a>
                    <a 
                      href="#" 
                      className="w-10 h-10 bg-gradient-primary rounded-full flex items-center justify-center text-primary-foreground hover:shadow-glow transition-all duration-300"
                    >
                      <Twitter size={20} />
                    </a>
                  </div>
                </CardContent>
              </Card>

              {/* Newsletter Signup */}
              <Card className="shadow-elegant">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Newsletter Signup</h3>
                  <p className="text-muted-foreground mb-4">
                    Get weekly updates about our events, resources, and opportunities.
                  </p>
                  <div className="space-y-3">
                    <Input 
                      type="email" 
                      placeholder="Enter your email"
                    />
                    <Button className="w-full bg-gradient-primary">
                      Subscribe to Newsletter
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Office Hours */}
              <Card className="shadow-elegant">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Office Hours</h3>
                  <div className="space-y-2 text-muted-foreground">
                    <p><strong>Mondays:</strong> 3:00 PM - 5:00 PM</p>
                    <p><strong>Wednesdays:</strong> 2:00 PM - 4:00 PM</p>
                    <p><strong>Fridays:</strong> 1:00 PM - 3:00 PM</p>
                  </div>
                  <p className="text-sm text-muted-foreground mt-4">
                    Drop by during office hours for informal chats about product management, career advice, or club activities.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Contact;