import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, MapPin, Users } from 'lucide-react';

const Events = () => {
  const upcomingEvents = [
    {
      id: 1,
      title: "Product Strategy Workshop",
      date: "March 15, 2024",
      time: "6:00 PM - 8:00 PM",
      location: "Lucas Hall 100",
      speaker: "Sarah Chen, Senior PM at Google",
      description: "Learn the fundamentals of product strategy and how to develop compelling product visions.",
      type: "Workshop",
      registered: 45,
      capacity: 60
    },
    {
      id: 2,
      title: "Startup Founder Panel",
      date: "March 22, 2024",
      time: "7:00 PM - 8:30 PM",
      location: "Sobrato Technology Center",
      speaker: "Multiple Industry Leaders",
      description: "Hear from successful startup founders about building products from 0 to 1.",
      type: "Panel",
      registered: 80,
      capacity: 100
    },
    {
      id: 3,
      title: "Product Management Case Competition",
      date: "April 5, 2024",
      time: "10:00 AM - 6:00 PM",
      location: "School of Business",
      speaker: "Competition Format",
      description: "Compete in teams to solve real product challenges and win exciting prizes.",
      type: "Competition",
      registered: 25,
      capacity: 40
    }
  ];

  const pastEvents = [
    {
      title: "User Research Fundamentals",
      date: "February 20, 2024",
      speaker: "Dr. Emily Rodriguez",
      attendees: 55
    },
    {
      title: "Product Analytics Deep Dive",
      date: "February 8, 2024",
      speaker: "Mark Johnson, Meta",
      attendees: 72
    },
    {
      title: "Design Thinking Workshop",
      date: "January 25, 2024",
      speaker: "Design Team from Airbnb",
      attendees: 68
    }
  ];

  return (
    <Layout>
      <div className="bg-gradient-subtle">
        {/* Header */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Events</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Join our workshops, speaker sessions, and networking events to advance your product management journey.
            </p>
          </div>
        </section>

        {/* Calendar Filter Section */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 mb-12">
          <div className="flex flex-wrap gap-4 justify-center">
            <Button variant="default" className="bg-gradient-primary">All Events</Button>
            <Button variant="outline">Workshops</Button>
            <Button variant="outline">Speaker Sessions</Button>
            <Button variant="outline">Networking</Button>
            <Button variant="outline">Competitions</Button>
          </div>
        </section>

        {/* Upcoming Events */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-3xl font-bold mb-8">Upcoming Events</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8">
            {upcomingEvents.map((event) => (
              <Card key={event.id} className="shadow-elegant hover:shadow-glow transition-all duration-300">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <Badge className="bg-gradient-primary text-primary-foreground">
                      {event.type}
                    </Badge>
                    <Badge variant="outline">
                      {event.registered}/{event.capacity} registered
                    </Badge>
                  </div>
                  <CardTitle className="text-xl">{event.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-4">
                    <div className="flex items-center text-muted-foreground">
                      <Calendar className="w-4 h-4 mr-2" />
                      {event.date}
                    </div>
                    <div className="flex items-center text-muted-foreground">
                      <Clock className="w-4 h-4 mr-2" />
                      {event.time}
                    </div>
                    <div className="flex items-center text-muted-foreground">
                      <MapPin className="w-4 h-4 mr-2" />
                      {event.location}
                    </div>
                    <div className="flex items-center text-muted-foreground">
                      <Users className="w-4 h-4 mr-2" />
                      {event.speaker}
                    </div>
                  </div>
                  <p className="text-muted-foreground mb-4 text-sm">
                    {event.description}
                  </p>
                  <Button className="w-full bg-gradient-primary shadow-elegant">
                    Register Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Past Events */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-3xl font-bold mb-8">Past Events</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pastEvents.map((event, index) => (
              <Card key={index} className="shadow-elegant">
                <CardContent className="p-6">
                  <h3 className="font-semibold text-lg mb-2">{event.title}</h3>
                  <div className="text-muted-foreground mb-2">{event.date}</div>
                  <div className="text-muted-foreground mb-3">{event.speaker}</div>
                  <div className="flex items-center text-sm">
                    <Users className="w-4 h-4 mr-1" />
                    {event.attendees} attendees
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default Events;