import Layout from '@/components/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, Target, BookOpen, Network } from 'lucide-react';

const About = () => {
  return (
    <Layout>
      <div className="bg-gradient-subtle">
        {/* Hero Section */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">About SCU Product Club</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Empowering Santa Clara University students to build successful careers in product management 
              through education, networking, and hands-on experience.
            </p>
          </div>
        </section>

        {/* Mission & Vision */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <Card className="shadow-elegant">
              <CardContent className="p-8">
                <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
                <p className="text-muted-foreground leading-relaxed">
                  To provide SCU students with the knowledge, skills, and network needed to excel in product management. 
                  We bridge the gap between academic learning and industry practice through workshops, speaker events, 
                  and hands-on projects.
                </p>
              </CardContent>
            </Card>
            
            <Card className="shadow-elegant">
              <CardContent className="p-8">
                <h2 className="text-2xl font-bold mb-4">Our Vision</h2>
                <p className="text-muted-foreground leading-relaxed">
                  To be the leading product management community at SCU, known for developing the next generation 
                  of innovative product leaders who will shape the future of technology and business.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* What We Offer */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h2 className="text-3xl font-bold text-center mb-12">What We Offer</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Education</h3>
              <p className="text-muted-foreground">
                Workshops, seminars, and resources covering product strategy, user research, and market analysis.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <Network className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Networking</h3>
              <p className="text-muted-foreground">
                Connect with industry professionals, alumni, and like-minded peers pursuing product careers.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Experience</h3>
              <p className="text-muted-foreground">
                Hands-on projects, case competitions, and internship opportunities with partner companies.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Community</h3>
              <p className="text-muted-foreground">
                Join a supportive community of aspiring product managers and experienced mentors.
              </p>
            </div>
          </div>
        </section>

        {/* Leadership Team Preview */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-8">Leadership Team</h2>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
              Our dedicated leadership team brings together students passionate about product management 
              and experienced in organizing impactful events and programs.
            </p>
            <Button className="bg-gradient-primary shadow-elegant">
              Meet Our Team
            </Button>
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default About;